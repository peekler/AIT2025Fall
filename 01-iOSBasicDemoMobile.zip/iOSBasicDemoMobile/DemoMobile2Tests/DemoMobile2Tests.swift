//
//  DemoMobile2Tests.swift
//  DemoMobile2Tests
//
//  Created by Peter Ekler on 2025. 09. 01..
//

import Testing
@testable import DemoMobile2

struct DemoMobile2Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
