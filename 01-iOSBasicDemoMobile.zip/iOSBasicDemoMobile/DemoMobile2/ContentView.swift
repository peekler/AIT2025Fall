//
//  ContentView.swift
//  DemoMobile2
//
//  Created by Peter Ekler on 2025. 09. 01..
//

import SwiftUI

struct ContentView: View {
    @State private var currentTime: String = ""
    
    
    var body: some View {
        VStack {
            Text(currentTime)
                            .font(.largeTitle)
                            .padding()
            Button("Current time") {
                //let formatter = DateFormatter()
                //formatter.dateFormat = "HH:mm:ss"
                //let timeString = formatter.string(from: Date())
                currentTime = "Current Time: \(Date().description)"
            }
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
