//
//  DemoMobile2App.swift
//  DemoMobile2
//
//  Created by Peter Ekler on 2025. 09. 01..
//

import SwiftUI

@main
struct DemoMobile2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
